let items = {};

function addItem() {
    const hsn = document.getElementById("hsn").value;
    const qty = parseFloat(document.getElementById("qty").value);
    const amount = parseFloat(document.getElementById("amount").value);
    const gst = parseFloat(document.getElementById("gst").value);

    if (!hsn || !qty || !amount || !gst) {
        alert("Please fill all fields");
        return;
    }

    if (!items[hsn]) {
        items[hsn] = { qty: 0, amount: 0, gst: gst };
    }

    items[hsn].qty += qty;
    items[hsn].amount += amount;

    renderTable();
}

function renderTable() {
    const tbody = document.querySelector("#summaryTable tbody");
    tbody.innerHTML = "";

    for (let hsn in items) {
        let row = items[hsn];

        let gstAmount = (row.amount * row.gst) / 100;
        let cgst = gstAmount / 2;
        let sgst = gstAmount / 2;

        tbody.innerHTML += `
            <tr>
                <td>${hsn}</td>
                <td>${row.qty.toFixed(2)}</td>
                <td>${row.amount.toFixed(2)}</td>
                <td>${row.gst}%</td>
                <td>${cgst.toFixed(2)}</td>
                <td>${sgst.toFixed(2)}</td>
                <td>${gstAmount.toFixed(2)}</td>
            </tr>
        `;
    }
}